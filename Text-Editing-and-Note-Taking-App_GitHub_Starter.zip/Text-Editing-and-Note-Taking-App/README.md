# Text Editing and Note Taking Application

## Team
- Cyril Jijo (Team Lead)
- Jeremiah Hackworth
- Jordyn Binkley

## Project Description
A web-based application that allows users to create, edit, organize, search, and manage digital notes.

## Features
- User Authentication
- Create/Edit/Delete Notes
- Folder Organization
- Search
- Autosave

## Suggested Tech Stack
- HTML/CSS/JavaScript
- Backend (replace with your team's implementation)
- Database (replace with your team's database)

## Repository Structure
See project folders.
